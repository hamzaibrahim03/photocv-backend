<?php return array (
  'Illuminate\\Foundation\\Support\\Providers\\EventServiceProvider' => 
  array (
    'App\\Listeners\\SchoolCreated' => 
    array (
      0 => 'App\\Listeners\\LogSchoolCreation@handle',
    ),
    'App\\Events\\CourseCreated' => 
    array (
      0 => 'App\\Listeners\\SendCourseCreatedNotification@handle',
    ),
    'App\\Events\\UserRegistered' => 
    array (
      0 => 'App\\Listeners\\SendUserRegisteredEmail@handle',
    ),
  ),
);