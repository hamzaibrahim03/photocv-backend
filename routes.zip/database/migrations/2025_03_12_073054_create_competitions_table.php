<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('competitions', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('club_id')->nullable();
            $table->string('featured_image', 250)->nullable();
            $table->string('name', 100)->nullable();
            $table->text('description')->nullable();
            $table->smallInteger('competition_type_id')->nullable();
            $table->smallInteger('judging_type_id')->nullable();
            $table->dateTime('start_date')->nullable();
            $table->dateTime('submission_deadline')->nullable()->comment('2 hours, 10 hours, 10 days etc');
            $table->smallInteger('max_entries_print')->nullable();
            $table->smallInteger('max_entries_digital')->nullable();
            $table->string('allowed_image_formats', 250)->nullable();
            $table->tinyInteger('max_file_size')->nullable()->comment('size in MBs');
            $table->enum('status', ['scheduled', 'postpond', 'draft', 'cancelled', 'completed'])->nullable()->default('scheduled');
            $table->smallInteger('category_id')->nullable();
            $table->smallInteger('theme_id')->nullable();
            $table->enum('print_vs_digital', ['print', 'digital'])->nullable();
            $table->enum('color_vs_mono', ['color', 'monochrome'])->nullable();
            $table->text('judging_panel')->nullable();
            $table->smallInteger('voting_method_id')->nullable();
            $table->smallInteger('result_method_id')->nullable();
            $table->dateTime('result_announcement_date')->nullable();
            $table->string('top_places', 20)->nullable();
            $table->tinyInteger('high_commendation_number')->nullable();
            $table->tinyInteger('commendation_number')->nullable();
            $table->text('prizes')->nullable();
            $table->boolean('cc_allowed')->nullable()->default(false);
            $table->boolean('auto_certificate')->nullable()->default(false);
            $table->boolean('allow_judges_feedback')->nullable()->default(false);
            $table->boolean('photographer_name')->nullable()->default(false);
            $table->boolean('comments')->nullable()->default(false);
            $table->boolean('scores')->nullable()->default(false);
            $table->boolean('position')->nullable()->default(false);
            $table->boolean('reels')->nullable()->default(false);
            $table->boolean('arrows')->nullable()->default(false);
            $table->boolean('comments_and_critique')->nullable()->default(false);
            $table->boolean('auto_generate_certificates')->nullable()->default(false);
            $table->boolean('visible_judges_feedback')->nullable()->default(false);
            $table->bigInteger('created_by')->nullable();
            $table->bigInteger('updated_by')->nullable();
            $table->bigInteger('deleted_by')->nullable();
            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('competitions');
    }
};
